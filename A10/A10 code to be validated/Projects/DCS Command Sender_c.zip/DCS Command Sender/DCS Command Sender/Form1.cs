﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO.Ports;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using SlimDX;
using SlimDX.DirectInput;


namespace DCS_Command_Sender
{
    public partial class Form1 : Form
    {


        bool bConfigMode = false;                                      //

        static Socket newsock;
        static EndPoint Remote;
        static EndPoint CDURemote;

        static string CurrentJoyStickGUID;

        const int SizeOfArray = 300;
        const int iMaxNoOfButtons = 6;
        bool[] bSwitchState = new bool[SizeOfArray];


        string[] Button_Names = new string[iMaxNoOfButtons];
        string[] Button_Number_String = new string[iMaxNoOfButtons];
        int[] Button_Number = new int[iMaxNoOfButtons];
        string[] Button_Down_Command_String = new string[iMaxNoOfButtons];
        int[] Button_Down_Command = new int[iMaxNoOfButtons];
        string[] Button_Up_Command_String = new string[iMaxNoOfButtons];
        int[] Button_Up_Command = new int[iMaxNoOfButtons];
        bool[] Button_Hold = new bool[iMaxNoOfButtons];


        static bool State_SAS_YAW_L = false ;
        int ButtonNo_SAS_YAW_L = 15;

        Joystick joystick;

        JoystickState state = new JoystickState();


        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender1, EventArgs e)
        {

            tSStatuslbl2.Text = "Listing Joysticks";
            PopulateJoystickListBox();

            tSStatuslbl2.Text = "Opening Configuration File";
            if (Properties.Settings.Default.JoystickGUID == "")
            {
                MessageBox.Show("New Configuration - Please Select a Joystick and Save Settings", "No Saved Settings", MessageBoxButtons.OK);
                DrawButtons();
            }
            else
            {
                // Get settings from configuration file
                CurrentJoyStickGUID = Properties.Settings.Default.JoystickGUID;



                // Populate Arrays from Settings files
                
                Button_Names  = Properties.Settings.Default.Button_Description.Split(new Char[] { ',' }, 100, StringSplitOptions.RemoveEmptyEntries);
                int t = 0;

                if (Button_Names.Length == 0)
                {

                    Button_Names = new string[iMaxNoOfButtons];
                    Button_Names[0] = "First Button";
                } 


                Button_Number_String = Properties.Settings.Default.Button_Number.Split(new Char[] {','},100,StringSplitOptions.RemoveEmptyEntries);
                for (int b = 0; b < Button_Number_String.Length ; b++)
                {
                   Button_Number[b] = Int32.Parse(Button_Number_String[b]); 
                }


                Button_Down_Command_String = Properties.Settings.Default.Button_Down_Command.Split(new Char[] { ',' }, 100, StringSplitOptions.RemoveEmptyEntries);
                for (int b = 0; b < Button_Down_Command_String.Length; b++)
                {
                    Button_Down_Command[b] = Int32.Parse(Button_Down_Command_String[b]);
                }

                Button_Up_Command_String = Properties.Settings.Default.Button_Up_Command.Split(new Char[] { ',' }, 100, StringSplitOptions.RemoveEmptyEntries);
                for (int b = 0; b < Button_Up_Command_String.Length; b++)
                {
                    Button_Up_Command[b] = Int32.Parse(Button_Up_Command_String[b]);
                }


                DrawButtons();


                
                ButtonNo_SAS_YAW_L = Properties.Settings.Default.ButtonNo_SAS_YAW_L;
                if (ButtonNo_SAS_YAW_L == 0)
                {
                    this.btn_L_Yaw_State.BackColor = Color.Yellow;
                    this.btn_L_Yaw_State.Text = "Click to Set L Yaw";
                }
                else
                {
                    this.lblYawStatusLeft.Text  = ButtonNo_SAS_YAW_L.ToString(); 
                }



            }
            
            tSStatuslbl2.Text = "Creating Socket";
            newsock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            
            IPEndPoint CDUSender = new IPEndPoint(IPAddress.Loopback, 7780);
            CDURemote = (EndPoint)(CDUSender);

            tSStatuslbl2.Text = "Creating Joystick Device";

            CreateJoystickDevice();
            tSStatuslbl2.Text = "Initialised";
        }




        public static void cdusendToLUA(String luaDevice, String luaButton, string luaButtonValue)
        {
            int recv;
            byte[] data = new byte[1024];
            byte[] data2 = new byte[1024];

            // Send the button press command to Export.lua
            data = Encoding.ASCII.GetBytes(luaDevice + "," + luaButton + "," + luaButtonValue);
            newsock.SendTo(data, data.Length, SocketFlags.None, CDURemote);

            Console.WriteLine("Sent to LUA - " + luaDevice + "," + luaButton + "," + luaButtonValue);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cdusendToLUA("C38", "3004", "1.0");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cdusendToLUA("C38", "3003", "0.0");
        }


        void PopulateJoystickListBox()
        {
            // make sure that DirectInput has been initialized
            DirectInput dinput = new DirectInput();

            // search for devices
            foreach (DeviceInstance device in dinput.GetDevices(DeviceClass.GameController, DeviceEnumerationFlags.AttachedOnly))
            {
                // create the device
                try
                {
                    joystick = new Joystick(dinput, device.InstanceGuid);

                    joystick.SetCooperativeLevel(this, CooperativeLevel.Nonexclusive | CooperativeLevel.Background);
                    lstAttachedSticks.Items.Add(joystick.Information.InstanceName + " " + joystick.Information.InstanceGuid);

                }
                catch (DirectInputException)
                {
                }
            }

            if (joystick == null)
            {
                MessageBox.Show("There are no joysticks attached to the system.");
                return;
            }


        }

        void CreateJoystickDevice()
        {
            // make sure that DirectInput has been initialized
            DirectInput dinput = new DirectInput();

            // search for devices
            foreach (DeviceInstance device in dinput.GetDevices(DeviceClass.GameController, DeviceEnumerationFlags.AttachedOnly))
            {
                // create the device
                try
                {
                    joystick = new Joystick(dinput, device.InstanceGuid);

                    joystick.SetCooperativeLevel(this, CooperativeLevel.Nonexclusive | CooperativeLevel.Background);

                    if (CurrentJoyStickGUID.ToString().Trim()  == joystick.Information.InstanceGuid.ToString().Trim())
                    {
                        
                        // Found the Joystick saved from last run - start monitoring
                        SetDevice(CurrentJoyStickGUID);
                    }
   
                
                }
                catch (DirectInputException)
                {
                }
            }

            if (joystick == null)
            {
                MessageBox.Show("There are no joysticks attached to the system.");
                return;
            }

            // acquire the device
            joystick.Acquire();

        }


        void ReadImmediateData()
        {
            if (joystick.Acquire().IsFailure)
                return;

            if (joystick.Poll().IsFailure)
                return;

            state = joystick.GetCurrentState();
            if (Result.Last.IsFailure)
                return;

            UpdateUI();
        }


        void UpdateUI()
        {

            tSStatuslbl1.Text  = DateTime.Now.ToString("HH:mm:ss tt");

            bool[] buttons = state.GetButtons();


            // Working here
            if (!bConfigMode)
            {
                for (int i = 0; i <iMaxNoOfButtons; i++)
                {
                    if ((buttons[Button_Number[i]] == true) && (bSwitchState[Button_Number[i]] == false))
                    {
                        bSwitchState[Button_Number[i]] = buttons[Button_Number[i]];
                        tSStatuslbl3.Text = Button_Number[i].ToString() + " State changed to on";
                        UpdateButtonColour("btn_" + i.ToString(), Color.Green);
                    }
                    else if((buttons[Button_Number[i]] == false) && (bSwitchState[Button_Number[i]] == true))
                    {
                        bSwitchState[Button_Number[i]] = buttons[Button_Number[i]];
                        tSStatuslbl3.Text = Button_Number[i].ToString() + " State changed to off";
                        UpdateButtonColour("btn_" + i.ToString(), Color.Red);
                    }

                }
            }

            if ((buttons[ButtonNo_SAS_YAW_L] == true) && (bSwitchState[ButtonNo_SAS_YAW_L] == false))
            {
                bSwitchState[ButtonNo_SAS_YAW_L] = buttons[ButtonNo_SAS_YAW_L];
                btn_L_Yaw_State.BackColor = Color.Green;
                cdusendToLUA("C38", "3004", "1.0");
            }
            else if ((buttons[ButtonNo_SAS_YAW_L] == false) && (bSwitchState[ButtonNo_SAS_YAW_L] == true))
            {
                bSwitchState[ButtonNo_SAS_YAW_L] = buttons[ButtonNo_SAS_YAW_L];
                btn_L_Yaw_State.BackColor = Color.Red;
                cdusendToLUA("C38", "3003", "0.0");
            }               

        }


        private void lstAttachedSticks_Click(object sender, EventArgs e)
        {
            string wrkstring;
            wrkstring = lstAttachedSticks.SelectedItem.ToString();
            wrkstring = wrkstring.Substring(wrkstring.LastIndexOf(" "), wrkstring.Length - wrkstring.LastIndexOf(" "));
            SetDevice(wrkstring);
        }


        void SetDevice(string GuidToMonitor)
        {
            string wrkstr;
            GuidToMonitor = GuidToMonitor.Trim();
            timer.Stop();
            // make sure that DirectInput has been initialized
            DirectInput dinput = new DirectInput();

            // search for devices
            foreach (DeviceInstance device in dinput.GetDevices(DeviceClass.GameController, DeviceEnumerationFlags.AttachedOnly))
            {
                // create the device
                try
                {
                    joystick = new Joystick(dinput, device.InstanceGuid);
                    joystick.SetCooperativeLevel(this, CooperativeLevel.Nonexclusive | CooperativeLevel.Background);
                    wrkstr = joystick.Information.InstanceGuid.ToString();
                    if (wrkstr == GuidToMonitor)
                    {
                        this.Text = "Monitoring Stick " + joystick.Information.InstanceName.ToString() + " (" + joystick.Information.InstanceGuid.ToString() + ")";
                        break;
                    }
                }
                catch (DirectInputException)
                {
                }
            }

            if (joystick == null)
            {
                MessageBox.Show("There are no joysticks attached to the system.");
                return;
            }



            // acquire the device
            joystick.Acquire();


            // set the timer to go off 12 times a second to read input
            // NOTE: Normally applications would read this much faster.
            // This rate is for demonstration purposes only.
            timer.Interval = 1000 / 12;
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            ReadImmediateData();
        }

        private void lstAttachedSticks_SelectedIndexChanged(object sender, EventArgs e)
        {
            string wrkstring;
            wrkstring = lstAttachedSticks.SelectedItem.ToString();
            wrkstring = wrkstring.Substring(wrkstring.LastIndexOf(" "), wrkstring.Length - wrkstring.LastIndexOf(" "));
            SetDevice(wrkstring);
            Properties.Settings.Default.JoystickGUID = wrkstring;
        }



        private void defaultConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Do you wish to erase all configuration data", "WARNING", MessageBoxButtons.YesNo);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Properties.Settings.Default.Reset();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string wrkstring;

            if (Properties.Settings.Default.JoystickGUID == "")
            {
                MessageBox.Show("Joystick Not Selected", "No Saved Settings", MessageBoxButtons.OK);
            }
            else
            {
                wrkstring = joystick.Information.InstanceName.ToString() + " (" + Properties.Settings.Default.JoystickGUID + ")" ;
                MessageBox.Show("Saving Settings for " + wrkstring, "Settings", MessageBoxButtons.OK);


                // Save Button Names Array
                wrkstring = Button_Names[0];
                for (int b = 1; b < Button_Names.Length; b++)
                {
                    if (Button_Names[b] != "")
                    {
                        wrkstring = wrkstring + "," + Button_Names[b];
                    }
                    else
                        break;

                }
                Properties.Settings.Default.Button_Description = wrkstring;


                // Save Button Number Array
                wrkstring = Button_Number[0].ToString();
                for (int b = 1; b < Button_Number.Length; b++)
                {
                    wrkstring = wrkstring + "," + Button_Number[b].ToString();
                }
                Properties.Settings.Default.Button_Number = wrkstring;

                // Save Button Command Down Array
                wrkstring = Button_Down_Command[0].ToString();
                for (int b = 1; b < Button_Down_Command.Length; b++)
                {
                    wrkstring = wrkstring + "," + Button_Down_Command[b].ToString();
                }
                Properties.Settings.Default.Button_Down_Command = wrkstring;


                // Save Button Command Up Array
                wrkstring = Button_Up_Command[0].ToString();
                for (int b = 1; b < Button_Up_Command.Length; b++)
                {
                    wrkstring = wrkstring + "," + Button_Up_Command[b].ToString();
                }
                Properties.Settings.Default.Button_Up_Command = wrkstring;


                Properties.Settings.Default.Save();
            }
        }

        private void btn_L_Yaw_State_Click(object sender, EventArgs e)
        {

            tSStatuslbl2.Text = "Please Press a Button";
            this.Refresh();

            bool FoundChange = false;
            int LoopCounter = 0;


            //Grab Current State of Joystick
            bool[] buttons = state.GetButtons();
            for (int c = 0; c < buttons.Length; c++)
            {
                bSwitchState[c] = buttons[c];
            }

            
            // Now loop looking for changes until one is found
            while( !FoundChange & (LoopCounter < 100))
            {
            
                tSStatuslbl1.Text = DateTime.Now.ToString("HH:mm:ss tt");
                tSStatuslbl2.Text = "Please Press a Button " + LoopCounter.ToString();
                this.Refresh();

                LoopCounter++;
                Thread.Sleep(100);


                state = joystick.GetCurrentState();
                buttons = state.GetButtons();

                for (int c = 0; c < buttons.Length; c++)
                {


                    if (buttons[c] != bSwitchState[c])
                    {
                        FoundChange = true;
                        tSStatuslbl2.Text = "Button " + c.ToString() + " pressed";
                        Properties.Settings.Default.ButtonNo_SAS_YAW_L = c;
                        MessageBox.Show("Found a change " + c.ToString());
                    }

                }
            
            }

            if (LoopCounter > 99)
                tSStatuslbl2.Text = "Timeout Selecting a button";
            else
            {
                // Save Button value to temporary value
            }

        }

        private void modifyConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            // Toggles the global state to enable editing of values - by defaulty this is disabled
            // Then enables or disables all text boxes on the form.

            Type type = typeof(System.Windows.Forms.TextBox);


            bConfigMode = !bConfigMode;
            
            foreach (Control control in this.Controls)
                // Only enable/disable text boxes on the form
                if (control.GetType() == type)
                    control.Enabled = bConfigMode;
          

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This isn't working", "Not working", MessageBoxButtons.OK);
            string arguments = string.Empty;
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 1; i < args.Length; i++) // args[0] is always exe path/filename
                arguments += args[i] + " ";

            // Restart current application, with same arguments/parameters
            Application.Exit();
            System.Diagnostics.Process.Start(Application.ExecutablePath, arguments);
        }


        private void DrawButtons()
        {
            for (int b = 0; b < Button_Names.Length; b++)
            {
                if (Button_Names[b] != "")
                {
                    var btn = new Button();
                    btn.Text = Button_Names[b];
                    btn.Tag = b;
                    btn.Location = new Point(90 * (b) + 10, 25);
                    btn.Click += (sender, args) =>
                    {

                        int iCurrentButtonPtr = Int32.Parse(((Button)sender).Tag.ToString());
                        // sender is the instance of the button that was clicked
                        //MessageBox.Show(((Button)sender).Tag.ToString() + " was clicked really ");
                        //MessageBox.Show(((Button)sender).Name.ToString());

                        tSStatuslbl2.Text = "Please Press a Button, mapping Buttton " + iCurrentButtonPtr.ToString();
                        this.Refresh();

                        bool FoundChange = false;
                        int LoopCounter = 0;


                        //Grab Current State of Joystick
                        bool[] buttons = state.GetButtons();
                        for (int c = 0; c < buttons.Length; c++)
                        {
                            bSwitchState[c] = buttons[c];
                        }


                        // Now loop looking for changes until one is found
                        while (!FoundChange & (LoopCounter < 100))
                        {

                            tSStatuslbl1.Text = DateTime.Now.ToString("HH:mm:ss tt");
                            tSStatuslbl2.Text = "Please Press a Button " + LoopCounter.ToString() + " - mapping Buttton " + iCurrentButtonPtr.ToString(); ;
                            this.Refresh();

                            LoopCounter++;
                            Thread.Sleep(100);


                            state = joystick.GetCurrentState();
                            buttons = state.GetButtons();

                            for (int c = 0; c < buttons.Length; c++)
                            {


                                if (buttons[c] != bSwitchState[c])
                                {
                                    FoundChange = true;
                                    tSStatuslbl2.Text = "Button " + c.ToString() + " pressed";

                                    Button_Number[iCurrentButtonPtr] = c;
                                    UpdateButtonValue("lbl_Number_" + iCurrentButtonPtr, c.ToString());


                                    Properties.Settings.Default.ButtonNo_SAS_YAW_L = c;
                                    MessageBox.Show("Found a change " + c.ToString());
                                }

                            }

                        }

                        if (LoopCounter > 99)
                            tSStatuslbl2.Text = "Timeout Selecting a button";
                        else
                        {
                            // Save Button value to temporary value
                        }

                    };
                    btn.Name = "btn_" + b;
                    Controls.Add(btn);



                    var lbl_Name = new TextBox();
                    lbl_Name.Text = Button_Names[b];
                    lbl_Name.Tag = b;
                    lbl_Name.Location = new Point(90 * (b) + 10, 50);
                    lbl_Name.Width = 70;
                    lbl_Name.Click += (sender, args) =>
                    {
                        // sender is the instance of the button that was clicked
                        //MessageBox.Show(((TextBox )sender).Tag.ToString() + " was clicked");
                    };
                    lbl_Name.LostFocus += (sender, args) =>
                    {
                        // Update Name for Button
                        string wrkstring = ((TextBox)sender).Text;

                        int iCurrentButtonPtr = Int32.Parse(((TextBox)sender).Tag.ToString());
                        Button_Names[iCurrentButtonPtr] = ((TextBox)sender).Text;
                        UpdateButtonValue("btn_" + iCurrentButtonPtr, wrkstring);
                    };
                    lbl_Name.Enabled = false;
                    lbl_Name.Name = "lbl_Name_" + b;
                    Controls.Add(lbl_Name);


                    var lbl_Number = new TextBox();
                    lbl_Number.Text = Button_Number[b].ToString();
                    lbl_Number.Tag = b;
                    lbl_Number.Location = new Point(90 * (b) + 10, 70);
                    lbl_Number.Width = 70;
                    lbl_Number.Click += (sender, args) =>
                    {
                        // sender is the instance of the button that was clicked
                        //MessageBox.Show(((TextBox )sender).Tag.ToString() + " was clicked");
                    };
                    lbl_Number.LostFocus += (sender, args) =>
                    {
                        // Update Name for Button
                        string wrkstring = ((TextBox)sender).Tag.ToString();
                        Button_Number[Int32.Parse(wrkstring)] = Int32.Parse(((TextBox)sender).Text);
                    };
                    lbl_Number.Enabled = false;
                    lbl_Number.Name = "lbl_Number_" + b;
                    Controls.Add(lbl_Number);


                    var lbl_Down_Command = new TextBox();
                    lbl_Down_Command.Text = Button_Down_Command[b].ToString();
                    lbl_Down_Command.Tag = b;
                    lbl_Down_Command.Location = new Point(90 * (b) + 10, 90);
                    lbl_Down_Command.Width = 70;
                    lbl_Down_Command.Click += (sender, args) =>
                    {
                        // sender is the instance of the button that was clicked
                        //MessageBox.Show(((TextBox )sender).Tag.ToString() + " was clicked");
                    };
                    lbl_Down_Command.LostFocus += (sender, args) =>
                    {
                        // Update Name for Button
                        string wrkstring = ((TextBox)sender).Tag.ToString();
                        Button_Down_Command[Int32.Parse(wrkstring)] = Int32.Parse(((TextBox)sender).Text);
                    };
                    lbl_Down_Command.Enabled = false;
                    Controls.Add(lbl_Down_Command);

                    var lbl_Up_Command = new TextBox();
                    lbl_Up_Command.Text = Button_Up_Command[b].ToString();
                    lbl_Up_Command.Tag = b;
                    lbl_Up_Command.Location = new Point(90 * (b) + 10, 110);
                    lbl_Up_Command.Width = 70;
                    lbl_Up_Command.Click += (sender, args) =>
                    {
                        // sender is the instance of the button that was clicked
                        //MessageBox.Show(((TextBox )sender).Tag.ToString() + " was clicked");
                    };
                    lbl_Up_Command.LostFocus += (sender, args) =>
                    {
                        // Update Name for Button
                        string wrkstring = ((TextBox)sender).Tag.ToString();
                        Button_Up_Command[Int32.Parse(wrkstring)] = Int32.Parse(((TextBox)sender).Text);
                    };
                    lbl_Up_Command.Enabled = false;
                    lbl_Up_Command.Name = "lbl_UpCommand_" + b;
                    Controls.Add(lbl_Up_Command);

                    this.Refresh();

                }
                else
                    break;

            }

         }


        private void UpdateButtonValue(string ControlToUpdate, string ValueToWrite)
        {
            foreach (Control control in this.Controls)
                // Only enable/disable text boxes on the form
                if (control.Name == ControlToUpdate)
                    control.Text = ValueToWrite;

        }

        private void UpdateButtonColour(string ControlToUpdate, Color ColorToWrite)
        {
            foreach (Control control in this.Controls)
                // Only enable/disable text boxes on the form
                if (control.Name == ControlToUpdate)
                    control.BackColor = ColorToWrite;

        }


    }


}
