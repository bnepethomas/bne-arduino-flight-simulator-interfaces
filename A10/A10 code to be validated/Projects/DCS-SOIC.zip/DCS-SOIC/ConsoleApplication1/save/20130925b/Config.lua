-- !!!!!FOR NETWORK MISSION MAKERS !!!!!
-- put this file to your mission package  Config/Export/Config.lua
--( miz file , it basicly ZIP archive,so just open it with your favorite archive manager)
-- to avoid using LoGetWorldObjects() and LoGetObjectById(id) functions 
-- this setting does not affected to server and single player game
EnableExportScript = true	-- set true to enable Export.lua script, please 
