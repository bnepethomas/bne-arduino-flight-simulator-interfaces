return {
["RAlt"] = {key = "RAlt", device = "Keyboard", switch = false},
["RWin"] = {key = "RWin", device = "Keyboard", switch = false},
["RShift"] = {key = "RShift", device = "Keyboard", switch = false},
["LWin"] = {key = "LWin", device = "Keyboard", switch = false},
["LShift"] = {key = "LShift", device = "Keyboard", switch = false},
["LCtrl"] = {key = "LCtrl", device = "Keyboard", switch = false},
["RCtrl"] = {key = "RCtrl", device = "Keyboard", switch = false},
["LAlt"] = {key = "LAlt", device = "Keyboard", switch = false},
}