﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Threading;
using System.Net.Sockets;
using System.Net;


namespace ArdunioCLISender
{
    class Program
    {
        static SerialPort _serialPort;

        static Socket newsock;

        static byte[] NULL = new byte[1] { 0x00 };
        static byte[] STX = new byte[1] { 0x02 };
        static byte[] ETX = new byte[1] { 0x03 };
        static byte[] CR = new byte[1] { 0x0d };


        static byte[] oled1 = new byte[1] { 0x01 };
        static byte[] oled2 = new byte[1] { 0x02 };
        static byte[] oled3 = new byte[1] { 0x03 };
        static byte[] oled4 = new byte[1] { 0x04 };
        static byte[] oled5 = new byte[1] { 0x05 };
        static byte[] oled6 = new byte[1] { 0x06 };
        static byte[] oled7 = new byte[1] { 0x07 };

        static byte[] CLS = new byte[1] { 0x7F };

        // Note that 0x02 and 0x03 are reserved for STX and ETX
        static byte[] FirstLine = new byte[1] { 0x01 };
        static byte[] SecondLine = new byte[1] { 0x02 };



        static bool bDebugFoundInCommandLine = false;
        static bool bShowTimeOnlyInCommandLine = false;


        static void Main(string[] args)
        {


            var sha1 = System.Security.Cryptography.SHA1.Create();
            byte[] buf;
            byte[] hash;
            string lastHash = "";
            string[] words;

            string lastILS = "";
            string lastChaffFlare = "";
            Console.WriteLine("Starting Arduino CLI Sender");

            //bool bDebugFoundInCommandLine=false;
            string sWorkstr;
            foreach (string s in args)
            {
                sWorkstr = s.ToLower();
                Console.WriteLine("Command-Line: " + sWorkstr);
                if (sWorkstr.Contains("debug"))
                {
                    bDebugFoundInCommandLine = true;
                }

                if (sWorkstr.Contains("time"))
                {
                    bShowTimeOnlyInCommandLine = true;
                }

            }
            if (bDebugFoundInCommandLine)
                Console.WriteLine("Debug requested, displayed received data");

            if (bShowTimeOnlyInCommandLine)
                Console.WriteLine("Time passed via Command Line - only updating clocks");


            // Setup call back function to clean up network ports on a CTRL-C
            Console.CancelKeyPress += delegate
            {
                cleanUp();
            };


            // Create a new SerialPort object with default settings.
            _serialPort = new SerialPort();

            // Allow the user to set the appropriate properties.
            _serialPort.PortName = "COM4";
            _serialPort.BaudRate = 115200;


            bool getakey = false;
            try 
            {
                if (!_serialPort.IsOpen)
                    _serialPort.Open();
            }
            // Lazy here, catch the COM Port not being available
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadKey(getakey);
                _serialPort.PortName = SetPortName("COM4");
            };

            try
            {

                //Creates a UdpClient for reading incoming data.
                UdpClient receivingUdpClient = new UdpClient(7781);
                Console.WriteLine("Listening on UDP Port " + receivingUdpClient.Client.LocalEndPoint);
                IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);


                // Couple of STX to sync up 
                _serialPort.Write(NULL, 0, 1);
                _serialPort.Write(NULL, 0, 1);

                _serialPort.Write(STX, 0, 1);
                _serialPort.Write(oled1, 0, 1);
                _serialPort.Write(FirstLine, 0, 1);
                _serialPort.Write(CLS, 0, 1);
                _serialPort.Write(ETX, 0, 1);

                _serialPort.Write(STX, 0, 1);
                _serialPort.Write(oled2, 0, 1);
                _serialPort.Write(FirstLine, 0, 1);
                _serialPort.Write(CLS, 0, 1);
                _serialPort.Write(ETX, 0, 1);



                while (bShowTimeOnlyInCommandLine)
                {
                    Thread.Sleep(80);
                    if (_serialPort.IsOpen)
                    {

                        SendToArduino(oled1, FirstLine, "1 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled2, FirstLine, "2 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled3, FirstLine, "3 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled4, FirstLine, "4 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled5, FirstLine, "5 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled6, FirstLine, "6 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                        SendToArduino(oled7, FirstLine, "7 - " + DateTime.Now.ToLongTimeString() + "  ");
                        Thread.Sleep(90);
                    }

                };



                SendToArduino(oled1, FirstLine, "aWaiting for data 1");
                Thread.Sleep(50);
                SendToArduino(oled2, FirstLine, "aWaiting for data 2");
                Thread.Sleep(50);
                SendToArduino(oled3, FirstLine, "aWaiting for data 3");
                Thread.Sleep(50);
                SendToArduino(oled4, FirstLine, "aWaiting for data 4");
                Thread.Sleep(50);
                SendToArduino(oled5, FirstLine, "aWaiting for data 5");
                Thread.Sleep(50);
                SendToArduino(oled6, FirstLine, "aWaiting for data 6");
                Thread.Sleep(50);
                SendToArduino(oled7, FirstLine, "aWaiting for data 7");
                Thread.Sleep(500);
                Thread.Sleep(50);
                sWorkstr = "";

                while (true)
                {
                    try
                    {

                        // Blocks until a message returns on this socket from a remote host.
                        Byte[] receiveBytes = receivingUdpClient.Receive(ref RemoteIpEndPoint);

                        string returnData = Encoding.ASCII.GetString(receiveBytes);

                        if (bDebugFoundInCommandLine)
                        {
                            Console.WriteLine("Payload received from DCS " +
                                                        returnData.ToString());
                            Console.WriteLine("This message was sent from " +
                                                        RemoteIpEndPoint.Address.ToString() +
                                                        " on their port number " +
                                                        RemoteIpEndPoint.Port.ToString());
                        }

                        // Basic test looking for differences - quick checksum - if different then split
                        buf = System.Text.Encoding.UTF8.GetBytes(returnData);
                        hash = sha1.ComputeHash(buf, 0, buf.Length);
                        sWorkstr = System.BitConverter.ToString(hash).Replace("-", "");
                        if (sWorkstr != lastHash)
                        {

                            lastHash = sWorkstr;

                            words = returnData.Split(new char[] { ':' }, 100, StringSplitOptions.RemoveEmptyEntries);
                            Console.WriteLine(words[0].ToString());

                            // VHF Radio

                            // VHF Radio values stored in values 157, 158, 159, 160

                            // ILS
                            sWorkstr = "ILS " + Get_Value(words, 8010) + "." + Get_Value(words, 8011);
                            if (sWorkstr != lastILS)
                            {
                                //sWorkstr = Get_Value(words, 157) + Get_Value(words, 158) + Get_Value(words, 159) + Get_Value(words, 160);
                                lastILS = sWorkstr;
                                SendToArduino(oled2, FirstLine, lastILS.PadRight(16));
                            }

                            // Chaff Flare
                            sWorkstr = "Chaff " + Get_Value(words, 8030) + "." + Get_Value(words, 8031);
                            if (sWorkstr != lastChaffFlare)
                            {
                                lastChaffFlare = sWorkstr;
                                SendToArduino(oled1, FirstLine, lastChaffFlare.PadRight(16));
                            }


                        }



                        

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadKey(getakey);
            };
            
        }


        static void SendToArduino(byte[] oledPtr, byte[] lineNumber, string StrToSend)
        {
            if (_serialPort.IsOpen)
            {
                _serialPort.Write(STX, 0, 1);
                _serialPort.Write(oledPtr, 0, 1);
                _serialPort.Write(lineNumber, 0, 1);
                _serialPort.Write(CR, 0, 1);
                _serialPort.Write(StrToSend);
                _serialPort.Write(ETX, 0, 1);
            }
        }

        // Display Port values and prompt user to enter a port. 
        static string SetPortName(string defaultPortName)
        {
            string portName;

            Console.WriteLine("Available Ports:");
            foreach (string s in SerialPort.GetPortNames())
            {
                Console.WriteLine("   {0}", s);
            }

            Console.Write("Enter COM port value (Default: {0}): ", defaultPortName);
            portName = Console.ReadLine();

            if (portName == "" || !(portName.ToLower()).StartsWith("com"))
            {
                portName = defaultPortName;
            }
            return portName;
        }


        public static string Get_Value(string[] DCSData, int ValueToReturn)
        {
            
            int TestPos = -1;
            string wrkstring;
            for (int i = 0; i < DCSData.Length; i++)
            {
                TestPos = DCSData[i].IndexOf(ValueToReturn.ToString());
                if ( TestPos != -1) 
                {
                    wrkstring = DCSData[i].Substring(ValueToReturn.ToString().Length + 1);
                    Console.WriteLine(wrkstring );
                    if (wrkstring.Length == 0)
                        wrkstring = " ";
                    return wrkstring;

                }
            }
            // If value not found return a space, better than a crash
            return " ";

        }

        public static void cleanUp()
        {
            Console.WriteLine("Closing Connections!");
            newsock.Close();
        }
    }
}
