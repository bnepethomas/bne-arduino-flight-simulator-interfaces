device_timer_dt     = 0.2

need_to_be_closed = true -- lua_state  will be closed in post_initialize()