dofile(LockOn_Options.common_script_path.."devices_defs.lua")

purposes 	 	= {render_purpose.GENERAL}
indicator_type 	= indicator_types.COMMON

page_subsets 	= {LockOn_Options.script_path.."TEWS/indicator/BAKE/RWR_ALR67_bake_page.lua"}
pages 			= {{1}}
init_pageID     = 1
