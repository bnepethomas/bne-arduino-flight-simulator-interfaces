dofile(LockOn_Options.script_path.."TEWS/indicator/RWR_ALR67_definitions.lua")
